<template>
<div>aaa, {{key}}
    <router-view></router-view>
    <router-link to='/login' v-if="currentRoute === '/'">Login</router-link>
    <router-link to='/' v-else>Home</router-link>
</div>
</template>
<script>
    export default {
        data(){
            return {
                key: 'test'
            }
        },
        computed: {
            currentRoute(){
                return this.$route.path
            }
        }
    }
</script>