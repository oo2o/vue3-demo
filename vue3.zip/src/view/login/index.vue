<template>
    <div>Login-{{session.user.name}}</div>
</template>
<script>
import { mapGetters } from 'vuex'
    export default {
        data(){
            return {

            }
        },
        computed: {
            ...mapGetters(['session'])
        }
    }
</script>