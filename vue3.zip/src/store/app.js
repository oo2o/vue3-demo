import { Store } from 'vuex'
import { STORE_KEY } from '../assets/js/constant.js'

const state = {
    session: {
        token: 'aaa',
        user: {
            name: 'test',
            avotr: ''
        }
    },
    theme: 'default'
}

const mutations = {
    [STORE_KEY.SET_LOGIN_USERINFO](state, user){
        if(user){
            state.session.user = user
        }
    },
    [STORE_KEY.SET_TOKEN](state, token){
        if(token){
            state.session.token = token
        }else{
            state.session.token = null
        }
    }
}

const actions = {
    Login(){

    },
    SetToken({ commit }, token){
        commit(STORE_KEY.SET_TOKEN, token)
    },
    KeepOnline({ state, commit }, { ctx, to, next }){

    }
}

const getters = {
    theme: state => state.theme,
    session: state => state.session
}

export default {
  state,
  getters,
  mutations,
  actions
}