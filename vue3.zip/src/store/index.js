
import app from './app'
import { createStore } from 'vuex'
import Vue from 'vue'

const store = createStore({
  modules: {
      app
  }
})

export default store
