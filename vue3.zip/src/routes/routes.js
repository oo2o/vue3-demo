const Home =() => import('../view/home/index.vue')
const Login =() => import('../view/login/index.vue')
export default [
    {
        path: '/',
        component: Home
    },
    {
        path: '/login',
        component: Login
    }
]