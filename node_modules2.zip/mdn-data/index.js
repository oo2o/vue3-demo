module.exports = {
  api: require('./api'),
  css: require('./css'),
  l10n: require('./l10n'),
}
