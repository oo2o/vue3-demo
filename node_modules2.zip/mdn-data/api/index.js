module.exports = {
  inheritance: require('./inheritance'),
}
