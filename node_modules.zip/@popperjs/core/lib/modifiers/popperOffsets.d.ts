import { Modifier } from "../types";
export declare type PopperOffsetsModifier = Modifier<"popperOffsets", {}>;
declare const _default: Modifier<"popperOffsets", {}>;
export default _default;
