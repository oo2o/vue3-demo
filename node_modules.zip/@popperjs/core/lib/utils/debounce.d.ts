export default function debounce<T>(fn: Function): () => Promise<T>;
