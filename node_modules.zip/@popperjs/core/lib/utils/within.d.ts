export default function within(min: number, value: number, max: number): number;
