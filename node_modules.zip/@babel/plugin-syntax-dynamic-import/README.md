# @babel/plugin-syntax-dynamic-import

> Allow parsing of import()

See our website [@babel/plugin-syntax-dynamic-import](https://babeljs.io/docs/en/next/babel-plugin-syntax-dynamic-import.html) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/plugin-syntax-dynamic-import
```

or using yarn:

```sh
yarn add @babel/plugin-syntax-dynamic-import --dev
```
